# assets/

This folder is for an optional demo track.

The `▶ PLAY` button in the transport row loads `assets/demo-song.wav`. Drop any
audio file here with that name and it will play. If you use a different format,
update `DEMO_TRACK` at the top of the DEMO section in `js/app.js`:

```js
const DEMO_TRACK = "assets/demo-song.mp3";
```

Audio files in this folder are gitignored by default — swap the rules in
`.gitignore` if you want to commit a royalty-free demo track with the repo.

Everything else works without this file: drag your own songs onto the shelf,
the tracklist, or the turntable.
